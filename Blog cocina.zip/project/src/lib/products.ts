export async function getFeaturedProducts() {
  // Simulamos datos de productos - En producción, esto vendría de una base de datos
  return [
    {
      name: "Set de Cuchillos Profesionales",
      slug: "set-cuchillos",
      price: 129.99,
      image: "https://images.unsplash.com/photo-1593618998160-e34014e67546?w=500"
    },
    {
      name: "Robot de Cocina Multifunción",
      slug: "robot-cocina",
      price: 299.99,
      image: "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?w=500"
    },
    {
      name: "Sartén Antiadherente Premium",
      slug: "sarten-premium",
      price: 49.99,
      image: "https://images.unsplash.com/photo-1620811449164-c84a6f2a24b4?w=500"
    },
    {
      name: "Báscula Digital de Cocina",
      slug: "bascula-digital",
      price: 24.99,
      image: "https://images.unsplash.com/photo-1591931559191-c6cc915e6cdb?w=500"
    }
  ];
}