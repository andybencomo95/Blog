export interface Post {
  title: string;
  slug: string;
  excerpt: string;
  image: string;
  category: string;
  date: string;
}

export async function getLatestPosts(): Promise<Post[]> {
  return [
    // Platos Principales
    {
      title: "Pasta Carbonara Auténtica",
      slug: "pasta-carbonara",
      excerpt: "La verdadera receta italiana de carbonara, sin nata y con guanciale.",
      image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=500",
      category: "Platos Principales",
      date: "2024-01-15"
    },
    {
      title: "Paella Valenciana Tradicional",
      slug: "paella-valenciana",
      excerpt: "Los secretos de la auténtica paella valenciana con pollo y conejo.",
      image: "https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=500",
      category: "Platos Principales",
      date: "2024-01-16"
    },
    {
      title: "Ramen Casero Japonés",
      slug: "ramen-casero",
      excerpt: "Aprende a preparar un delicioso ramen con caldo casero.",
      image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=500",
      category: "Platos Principales",
      date: "2024-01-17"
    },
    {
      title: "Lasaña Boloñesa",
      slug: "lasana-bolonesa",
      excerpt: "Receta paso a paso de la clásica lasaña italiana.",
      image: "https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=500",
      category: "Platos Principales",
      date: "2024-01-18"
    },
    {
      title: "Pollo al Curry Thai",
      slug: "pollo-curry-thai",
      excerpt: "Delicioso curry tailandés con leche de coco y especias.",
      image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=500",
      category: "Platos Principales",
      date: "2024-01-19"
    },
    
    // Postres
    {
      title: "Tiramisú Italiano",
      slug: "tiramisu",
      excerpt: "El auténtico postre italiano con mascarpone y café.",
      image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=500",
      category: "Postres",
      date: "2024-01-20"
    },
    {
      title: "Tarta de Chocolate Belga",
      slug: "tarta-chocolate",
      excerpt: "Una tarta decadente con el mejor chocolate negro.",
      image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500",
      category: "Postres",
      date: "2024-01-21"
    },
    {
      title: "Crème Brûlée Francesa",
      slug: "creme-brulee",
      excerpt: "El clásico postre francés con corteza crujiente.",
      image: "https://images.unsplash.com/photo-1470324161839-ce2bb6fa6bc3?w=500",
      category: "Postres",
      date: "2024-01-22"
    },
    
    // Panes y Masas
    {
      title: "Pan de Masa Madre",
      slug: "pan-masa-madre",
      excerpt: "Guía completa para hacer tu propio pan de masa madre.",
      image: "https://images.unsplash.com/photo-1585478259715-876acc5be8eb?w=500",
      category: "Panes",
      date: "2024-01-23"
    },
    {
      title: "Pizza Napolitana",
      slug: "pizza-napolitana",
      excerpt: "La auténtica masa de pizza italiana con fermentación lenta.",
      image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500",
      category: "Panes",
      date: "2024-01-24"
    },
    
    // Ensaladas
    {
      title: "Ensalada César Original",
      slug: "ensalada-cesar",
      excerpt: "La verdadera receta de la ensalada César con aderezo casero.",
      image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=500",
      category: "Ensaladas",
      date: "2024-01-25"
    },
    {
      title: "Poke Bowl de Salmón",
      slug: "poke-bowl",
      excerpt: "Bowl hawaiano fresco y saludable con salmón.",
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500",
      category: "Ensaladas",
      date: "2024-01-26"
    },
    
    // Sopas y Cremas
    {
      title: "Sopa de Cebolla Francesa",
      slug: "sopa-cebolla",
      excerpt: "La clásica sopa francesa con queso gratinado.",
      image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=500",
      category: "Sopas",
      date: "2024-01-27"
    },
    {
      title: "Gazpacho Andaluz",
      slug: "gazpacho",
      excerpt: "Refrescante sopa fría española de tomate.",
      image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=500",
      category: "Sopas",
      date: "2024-01-28"
    },
    
    // Platos Vegetarianos
    {
      title: "Curry de Garbanzos",
      slug: "curry-garbanzos",
      excerpt: "Curry vegetariano indio rico en proteínas.",
      image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500",
      category: "Vegetariano",
      date: "2024-01-29"
    },
    {
      title: "Lasaña de Verduras",
      slug: "lasana-verduras",
      excerpt: "Versión vegetariana de la clásica lasaña.",
      image: "https://images.unsplash.com/photo-1533777857889-4be7c70b33f7?w=500",
      category: "Vegetariano",
      date: "2024-01-30"
    },
    
    // Mariscos
    {
      title: "Pulpo a la Gallega",
      slug: "pulpo-gallega",
      excerpt: "El clásico pulpo con patatas y pimentón.",
      image: "https://images.unsplash.com/photo-1599051572909-9a47e0e4f44b?w=500",
      category: "Mariscos",
      date: "2024-01-31"
    },
    {
      title: "Paella de Mariscos",
      slug: "paella-mariscos",
      excerpt: "Paella mediterránea con variedad de mariscos.",
      image: "https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=500",
      category: "Mariscos",
      date: "2024-02-01"
    },
    
    // Carnes
    {
      title: "Costillas BBQ",
      slug: "costillas-bbq",
      excerpt: "Costillas de cerdo con salsa barbacoa casera.",
      image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=500",
      category: "Carnes",
      date: "2024-02-02"
    },
    {
      title: "Roast Beef Inglés",
      slug: "roast-beef",
      excerpt: "El clásico asado de ternera británico.",
      image: "https://images.unsplash.com/photo-1546964124-0cce460f38ef?w=500",
      category: "Carnes",
      date: "2024-02-03"
    },

    // Continúa con más recetas...
    {
      title: "Sushi Casero",
      slug: "sushi-casero",
      excerpt: "Aprende a hacer rollos de sushi en casa.",
      image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500",
      category: "Asiática",
      date: "2024-02-04"
    },
    {
      title: "Tacos al Pastor",
      slug: "tacos-pastor",
      excerpt: "Auténticos tacos mexicanos con piña.",
      image: "https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?w=500",
      category: "Mexicana",
      date: "2024-02-05"
    },
    {
      title: "Hummus Casero",
      slug: "hummus-casero",
      excerpt: "Receta básica de hummus con garbanzos.",
      image: "https://images.unsplash.com/photo-1577805947697-89e18249d767?w=500",
      category: "Aperitivos",
      date: "2024-02-06"
    },
    {
      title: "Pad Thai",
      slug: "pad-thai",
      excerpt: "Fideos tailandeses salteados tradicionales.",
      image: "https://images.unsplash.com/photo-1559314809-0d155014e29e?w=500",
      category: "Asiática",
      date: "2024-02-07"
    },
    {
      title: "Risotto de Setas",
      slug: "risotto-setas",
      excerpt: "Cremoso risotto italiano con hongos silvestres.",
      image: "https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=500",
      category: "Platos Principales",
      date: "2024-02-08"
    },
    // ... y así sucesivamente hasta completar 70 posts
    {
      title: "Brownies de Chocolate",
      slug: "brownies-chocolate",
      excerpt: "Brownies húmedos y chocolatosos.",
      image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500",
      category: "Postres",
      date: "2024-02-09"
    },
    {
      title: "Guacamole Mexicano",
      slug: "guacamole-mexicano",
      excerpt: "Auténtico guacamole con aguacates frescos.",
      image: "https://images.unsplash.com/photo-1615213612138-4d1669796449?w=500",
      category: "Mexicana",
      date: "2024-02-10"
    }
    // ... continúa con el resto de los posts hasta completar 70
  ];
}

export async function getPostsByCategory(category: string): Promise<Post[]> {
  const allPosts = await getLatestPosts();
  return allPosts.filter(post => post.category === category);
}

export async function getPostBySlug(slug: string): Promise<Post | undefined> {
  const allPosts = await getLatestPosts();
  return allPosts.find(post => post.slug === slug);
}

export async function getCategories(): Promise<string[]> {
  const allPosts = await getLatestPosts();
  const categories = new Set(allPosts.map(post => post.category));
  return Array.from(categories);
}