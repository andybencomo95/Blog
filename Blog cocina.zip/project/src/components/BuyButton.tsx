import { useState } from 'react';

interface BuyButtonProps {
  productId: string;
  price: number;
}

export default function BuyButton({ productId, price }: BuyButtonProps) {
  const [loading, setLoading] = useState(false);

  const handleBuy = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/create-checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId,
          price,
        }),
      });
      
      const { url } = await response.json();
      window.location.href = url;
    } catch (error) {
      console.error('Error al procesar la compra:', error);
      alert('Hubo un error al procesar tu compra. Por favor intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleBuy}
      disabled={loading}
      className="w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 disabled:opacity-50"
    >
      {loading ? 'Procesando...' : 'Comprar Ahora'}
    </button>
  );
}