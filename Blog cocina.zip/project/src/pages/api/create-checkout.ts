// For static deployment, we'll use a redirect to Stripe
import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, redirect }) => {
  try {
    const body = await request.json();
    const { productId, price } = body;
    
    // For demo purposes, redirect to success page
    return redirect('/tienda/success');
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Error processing checkout' }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
  }
}